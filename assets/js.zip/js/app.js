(function(){
	angular.module('fileManager',['ngRoute', 'ngMaterial', 'ngMdIcons', 'ng-fx', 'ngAnimate','ngFileUpload','firebase'])
	.config(['$routeProvider', '$mdThemingProvider', function($routeProvider, $mdThemingProvider) {
			$routeProvider.when('/', {
				templateUrl: 'assets/views/login.html',
				controller: 'loginCtrl'
			})
			.when('/upload', {
				templateUrl: 'assets/views/upload.html',
				controller: 'uploadCtrl',
				resolve: {
						userFolder : function(auth, rootRef, $firebaseStorage) {
							return auth.$requireSignIn();
								}
						}
			})
			.when('/all', {
				templateUrl: 'assets/views/allFiles.html',
				controller: 'allFilesCtrl'
			})
			.otherwise({
        		redirectTo: '/'
      		});
			$mdThemingProvider.theme('default')
				.primaryPalette('blue-grey')
				.accentPalette('amber');
		}]);
})();