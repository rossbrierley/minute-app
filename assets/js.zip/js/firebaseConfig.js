
			var config = {
    			apiKey: "AIzaSyDi3twiBjCLGUmn03JMV8hmg3tXG2maY3Y",
    			authDomain: "minutesapp-25999.firebaseapp.com",
    			databaseURL: "https://minutesapp-25999.firebaseio.com",
    			projectId: "minutesapp-25999",
    			storageBucket: "gs://minutesapp-25999.appspot.com",
    			messagingSenderId: "610881330355"
  			};
  			firebase.initializeApp(config);
