(function(){
		angular.module('fileManager')
			   .factory('rootRef', function() {
					return firebase.database().ref();
			});
})();
