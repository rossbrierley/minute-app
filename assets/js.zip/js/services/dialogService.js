(function() {
	angular.module('fileManager')
		   .factory('dialogService',[function(){
		   	currentlyReading = {};
		   	return currentlyReading;
		   
	}])
})();