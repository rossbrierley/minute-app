(function() {
	angular.module('fileManager')
           .factory('auth', function($firebaseAuth, rootRef) {
				return $firebaseAuth();
	})
})()